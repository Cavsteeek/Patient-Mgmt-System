package com.pm.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
